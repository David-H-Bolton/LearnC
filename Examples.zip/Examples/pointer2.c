#include <stdio.h>

void inc(int * pvalue) {
	*pvalue = *pvalue + 1;
}

int main()
{
	int a = 1;
	int * pa = &a;
	inc(pa);
	printf("%i\n", a);
}
