#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char * name = "David";

int main()
{
	int len = strlen(name);
	printf("Length of string %s is %d\n", name, len);
}
