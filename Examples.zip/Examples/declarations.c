#include <stdio.h>

int main()
{
	int numAsteroids = 37;
	int direction;
	float total = 0.0f;
	unsigned int counter;
	int count = 0;
	int height;
	short int littlevariable = 10;
	long long bignumber = 1000000000000000;
	unsigned long long biggernumber = 10000000000000000;
	
	return 0;
}
