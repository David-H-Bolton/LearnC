#include <stdio.h>

struct ErrorParm {
	int value;
	int errorNum;
};

struct ErrorParm DoCalculation(int x, int y) {
	struct ErrorParm result;
	result.errorNum = 0;
	result.value = x + y;
	if (result.value < 0) {
		result.errorNum = 1;
	}
	return result;
}

int main()
{
	int x = -6;
	int y = 5;
	struct ErrorParm calcValue;
	calcValue = DoCalculation(x, y);
	printf("Value = %d Error = %d\n", calcValue.value, calcValue.errorNum);
	return 0;
}

