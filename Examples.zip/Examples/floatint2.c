#include <stdio.h>

typedef struct {
	float f;
	short i;
	int values[10];
} FloatInts;

int main()
{
	FloatInts s; // look no struct needed!
	FloatInts s2;
	s.f = 47;
	s2 = s;
	printf("s2.f = %f\n", s2.f);
	return 0;
}

