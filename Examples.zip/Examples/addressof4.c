#include <stdio.h>
#include <stdlib.h>

int array1[10];
int * p1 = array1;
int * p2 = _ADDRESSOF(array1);
int * p3 = _ADDRESSOF(array1[0]);

int main()
{
	printf("p1 = %p\np2 = %p\np3 = %p\n", p1, p2, p3);
}
