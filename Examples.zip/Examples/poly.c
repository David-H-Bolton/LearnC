#include <stdio.h>

#define A 3
#define B 6
#define C -7

int CalculatePolynomial(int x) {
	return (A * x * x) + (B * x) + C;
}

int main()
{
	for (int x = 1; x <= 5; x++) {
		int y = CalculatePolynomial(x);
		printf("X = %d Y = %d\n", x, y);
	}
	return 0;
}
