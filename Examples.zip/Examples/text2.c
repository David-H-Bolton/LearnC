#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char buffer[100];
char numberBuffer[10];
int score = 999;

int main()
{
	memcpy(buffer, "*******************", 20);
	sprintf_s(buffer, sizeof(buffer) - 1, "Score:%d", score++);
	printf("%s\n", buffer);

	_ltoa_s(score, numberBuffer, sizeof(numberBuffer) - 1, 10);
	sprintf_s(buffer, sizeof(buffer) - 1, "Score:");
	strcat_s(buffer, sizeof(buffer) - 1, numberBuffer);
	printf("%s\n", buffer);
}
