#include <stdio.h>
#include <stdlib.h>

int a1;
int a2;

int main()
{
	printf("Address a1 = %p\nAddress a2 = %p\n", _ADDRESSOF(a1), _ADDRESSOF(a2));
	printf("Address of main() function = %p\n", main);
}

