#include <stdio.h>
#include <stdlib.h>

int a1;
int a2;
int * p1 = _ADDRESSOF(a1);
int * p2 = _ADDRESSOF(a2);

int main()
{
	printf("Address of a1 = %p\nAddress of a2 = %p\n", _ADDRESSOF(a1), _ADDRESSOF(a2));
	printf("Address in p1 = %p\nAddress in p2 = %p\n", p1, p2);
	printf("Address of p1 = %p\nAddress of p2 = %p\n", _ADDRESSOF(p1), _ADDRESSOF(p2));
}
